//
//  ContentView.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import SwiftUI

struct ContentView: View {
    
    var users: [User] = User.getUsers()
    
    @State private var showActionSheet = false
    
    var postsData: [PostListRepresentation] {
        var postsData: [PostListRepresentation] = []
        
        for user in users {
            for post in user.posts {
                let postData = PostListRepresentation(profileImage: user.profileImage, profileName: user.profileName, image: post.image, likesCount: post.likesCount, date: post.date, description: post.description, isLiked: post.isLiked, isSaved: post.isSaved)
                postsData.append(postData)
            }
        }
        
        return postsData.sorted { $0.date >= $1.date }
    }
    
    
    var body: some View {
        NavigationView {
            ZStack {
                VStack(spacing: 0) {
                    HStack {
                        Text("Instagram")
                            .font(.custom("billabong", size: 35))
                        Spacer()
                        NavigationLink(destination: ChatView(users: users)) {
                            Image(systemName: "message")
                                .font(.system(size: 24))
                                .foregroundColor(.black)
                        }
                    }
                    .padding(.horizontal)
                    .frame(height: 50)
                   
                    ScrollView(showsIndicators: false) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                StoryIcon(profileImage: users.first!.profileImage,
                                          profileName: users.first!.profileName,
                                          storyType: .myStory,
                                          hasUnwatchedStories: users.first!.hasUnwatchedStories,
                                          hideProfileName: false)
                                ForEach(users[1...], id: \.self) { user in
                                    StoryIcon(profileImage: user.profileImage,
                                              profileName: user.profileName,
                                              storyType: .other,
                                              hasUnwatchedStories: user.hasUnwatchedStories,
                                              hideProfileName: false)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.vertical, 2)
                        }
                        .frame(height: 90)
                        
                        Divider()
                        
                        VStack {
                            ForEach(postsData, id: \.profileName) { post in
                                PostRow(post: post) {
                                    showActionSheet.toggle()
                                }
                            }
                        }
                    }
                }
                
                if showActionSheet {
                    Color.black.opacity(0.3)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            showActionSheet.toggle()
                        }
                }
                
                VStack {
                    Spacer()
                    
                    VStack(spacing: 8) {
                        VStack(spacing: 0) {
                            Button(action: { showActionSheet.toggle() }) {
                                Text("Пожаловаться")
                                    .foregroundColor(.red)
                                    .frame(height: 60)
                                    .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                    .foregroundColor(.black)
                                
                            }
                            Divider()
                            Button(action: { showActionSheet.toggle() }) {
                                Text("Копировать ссылку")
                                    .frame(height: 60)
                                    .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                    .foregroundColor(.black)
                                
                            }
                            Divider()
                            Button(action: { showActionSheet.toggle() }) {
                                Text("Поделиться...")
                                    .frame(height: 60)
                                    .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                    .foregroundColor(.black)
                                
                            }
                            Divider()
                            Button(action: { showActionSheet.toggle() }) {
                                Text("Включить уведомления о публикациях")
                                    .frame(height: 60)
                                    .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                    .foregroundColor(.black)
                                
                            }
                            Divider()
                            Button(action: { showActionSheet.toggle() }) {
                                Text("Скрыть")
                                    .frame(height: 60)
                                    .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                    .foregroundColor(.black)
                                
                            }
                        }
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                .foregroundColor(.white)
                        )
                        
                        Button(action: { showActionSheet.toggle() }) {
                            Text("Отменить")
                                .frame(height: 60)
                                .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                .foregroundColor(.black)
                        }
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .frame(maxWidth: UIScreen.main.bounds.width - 32)
                                .foregroundColor(Color.white)
                        )
                    }
                    
                }
                .offset(y: showActionSheet ? -16 : UIScreen.main.bounds.height)
            }
            .animation(.default)
            .navigationBarHidden(true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
