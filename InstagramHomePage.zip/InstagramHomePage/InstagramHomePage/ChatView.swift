//
//  ChatView.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import SwiftUI

struct ChatView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State private var text: String = ""
    let users: [User]
    
    init(users: [User]) {
        self.users = users.shuffled()
        UITableView.appearance().separatorColor = .clear
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 16) {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 24))
                        .foregroundColor(.black)
                }
                
                Text("m_bashtaev")
                    .font(.system(size: 30, weight: .semibold))
                Spacer()
                
                Button(action: {}) {
                    Image(systemName: "video")
                        .font(.system(size: 24))
                        .foregroundColor(.black)
                }
                Button(action: {}) {
                    Image(systemName: "square.and.pencil")
                        .font(.system(size: 24))
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal)
            .frame(height: 50)
            
            TextField("Поиск", text: $text)
                .frame(height: 40)
                .padding(.horizontal)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(red: 239 / 255, green: 239 / 255, blue: 239 / 255))
                )
                .padding(.horizontal)
            
            List(users, id: \.profileName) { user in
                ChatRow(profileImage: user.profileImage, profileName: user.profileName, hasUnwatchedStories: user.hasUnwatchedStories)
            }
        }
        .navigationBarHidden(true)
    }
}

struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView(users: User.getUsers())
    }
}
