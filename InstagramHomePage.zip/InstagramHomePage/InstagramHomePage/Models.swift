//
//  Models.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import Foundation
import SwiftUI

struct User: Hashable, Equatable {
    static func == (lhs: User, rhs: User) -> Bool {
        return lhs.profileName == rhs.profileName
    }
    
    var profileName: String
    var profileImage: UIImage
    var posts: [Post]
    var stories: [Story]
    var hasUnwatchedStories = false
    
    static func getUsers() -> [User] {
        let user1 = User(profileName: "m_bashtaev",
                         profileImage: UIImage(named: "m_bashtaev-profile-image")!,
                         posts: [
//                            Post(image: UIImage(named: "m_bashtaev-photo")!,
//                                 likesCount: 12,
//                                 description: "Последние соревнования по спидкубингу",
//                                 date: Calendar.current.dateFrom(year: 2020, month: 3, day: 20))
                         ],
                         stories: [])
        
        
        let user2 = User(profileName: "SpaceX",
                         profileImage: UIImage(named: "spacex-profile-image")!,
                         posts: [
                            Post(image: UIImage(named: "spacex-photo")!,
                                 likesCount: 3_202_349,
                                 description: "SpaceX Starship | SN8 | High-Altitude Flight Test",
                                 date: Calendar.current.dateFrom(year: 2020, month: 12, day: 8))
                         ],
                         stories: [],
                         hasUnwatchedStories: false)
        
        let user3 = User(profileName: "Pikachu",
                         profileImage: UIImage(named: "pikachu-profile-image")!,
                         posts: [
                            Post(image: UIImage(named: "pikachu-photo")!,
                                                likesCount: 532_021,
                                                description: "Когда до сессии осталось 3 недели😭",
                                                date: Date())
                         ],
                         stories: [],
                         hasUnwatchedStories: true)
        
        let user4 = User(profileName: "Apple",
                         profileImage: UIImage(named: "apple-profile-image")!,
                         posts: [
                            Post(image: UIImage(named: "apple-photo")!,
                                 likesCount: 4_202_857,
                                 description: "The Apple M1 is an ARM-based system from the Apple Silicon series used in Mac computers, MacBooks, and iPad Pro tablets. MacBook Pro 2020, MacBook Air 2020 and Mac Mini 2020 are the first devices on the M1",
                                 date: Calendar.current.dateFrom(year: 2020, month: 11, day: 29))
                         ],
                         stories: [],
                         hasUnwatchedStories: true)
        
        let user5 = User(profileName: "Tesla",
                         profileImage: UIImage(named: "tesla-profile-image")!,
                         posts: [
                            Post(image: UIImage(named: "tesla-photo")!,
                                 likesCount: 2_103_110,
                                 description: "Tesla Cybertruck - electric pickup truck. Depending on the model, the pickup should travel up to 500 km on a single charge. The declared carrying capacity is about 1.6 tons.",
                                 date: Calendar.current.dateFrom(year: 2019, month: 11, day: 19))
                         ],
                         stories: [])
        
        
        
        return [user1, user2, user3, user4, user5]
    }
}

struct Story: Hashable {
    var imageString: String
    
    init() {
        imageString = ""
    }
}

typealias PostData = (profileImage: UIImage, profileName: String, image: UIImage, likesCount: Int, date: Date)

struct PostListRepresentation: Hashable {
    
    let profileImage: UIImage
    let profileName: String
    let image: UIImage
    let likesCount: Int
    let date: Date
    let description: String
    var isLiked: Bool
    var isSaved: Bool
}

struct Post: Hashable {
    var image: UIImage
    var likesCount: Int
    var description: String
    var date: Date
    var isLiked = false
    var isSaved = false
    
    init(image: UIImage = UIImage(), likesCount: Int = 0, description: String = "", date: Date = Date()) {
        self.image = image
        self.likesCount = likesCount
        self.description = description
        self.date = date
    }
}

extension Calendar {
    func dateFrom(year: Int, month: Int, day: Int) -> Date {
        return Calendar.current.date(from: DateComponents(year: year, month: month, day: day)) ?? Date()
    }
}
