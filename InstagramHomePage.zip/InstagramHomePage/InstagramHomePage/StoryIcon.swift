//
//  StoryIcon.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import SwiftUI

struct StoryIcon: View {
    
    let profileImage: UIImage
    let profileName: String
    let storyType: StoryType
    let hasUnwatchedStories: Bool
    let hideProfileName: Bool
    
    enum StoryType {
        case myStory
        case other
    }
    
    let colors: [Color] = [
        Color(red: 245 / 255, green: 133 / 255, blue: 41 / 255),
        Color(red: 254 / 255, green: 218 / 255, blue: 119 / 255),
        Color(red: 221 / 255, green: 42 / 255, blue: 123 / 255),
        Color(red: 129 / 255, green: 52 / 255, blue: 175 / 255),
        Color(red: 81 / 255, green: 91 / 255, blue: 212 / 255),
    ]
    
    var body: some View {
        view()
    }
    
    func view() -> some View {
        VStack {
            ZStack {
                if hasUnwatchedStories {
                    Circle()
                        .strokeBorder(
                            LinearGradient(gradient: Gradient(colors: colors), startPoint: .top, endPoint: .bottom), lineWidth: 2
                        )
                } else {
                    if storyType == .other {
                        Circle()
                            .stroke(lineWidth: 1)
                            .foregroundColor(.gray)
                    }
                }
                ZStack(alignment: .bottomTrailing) {
                    Image(uiImage: profileImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                    
                    if storyType == .myStory && hasUnwatchedStories == false {
                        ZStack {
                            Circle()
                                .frame(width: 24, height: 24)
                                .foregroundColor(.white)
                            Circle()
                                .foregroundColor(.blue)
                                .overlay(
                                    Image(systemName: "plus")
                                        .resizable()
                                        .frame(width: 10, height: 10)
                                        .foregroundColor(.white)
                                )
                                .frame(width: 20, height: 20)
                        }
                        .offset(x: 2, y: 2)
                    }
                }
            }
            .frame(width: 58, height: 58)

            if hideProfileName == false {
                Text(profileName)
                    .font(.system(size: 9))
                    .foregroundColor(.secondary)
            }
        }
    }
    
    func myStoryView() -> some View {
        VStack {
            ZStack(alignment: .bottomTrailing) {
                Image(uiImage: profileImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())
                ZStack {
                    Circle()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.white)
                    Circle()
                        .foregroundColor(.blue)
                        .overlay(
                            Image(systemName: "plus")
                                .resizable()
                                .frame(width: 10, height: 10)
                                .foregroundColor(.white)
                        )
                        .frame(width: 20, height: 20)
                }
            }
            .frame(width: 56, height: 56)
            
            Text(profileName)
                .font(.system(size: 9))
                .foregroundColor(.secondary)
        }
        .frame(width: 60, height: 70)
    }
    func otherView() -> some View {
        VStack {
            ZStack {
                Circle()
                    .strokeBorder(
                        LinearGradient(gradient: Gradient(colors: colors), startPoint: .top, endPoint: .bottom), lineWidth: 2
                    )
                    .frame(width: 56, height: 56)
                Image(uiImage: profileImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())
            }
            
            
            Text(profileName)
                .font(.system(size: 9))
                .foregroundColor(.secondary)
        }
        .frame(width: 60, height: 70)
    }
}

struct StoryIcon_Previews: PreviewProvider {
    static var previews: some View {
        HStack {
            StoryIcon(profileImage: UIImage(named: "m_bashtaev-profile-image")!, profileName: "m_bashtaev", storyType: .myStory, hasUnwatchedStories: false, hideProfileName: false)
            StoryIcon(profileImage: UIImage(named: "spacex-profile-image")!, profileName: "SpaceX", storyType: .other, hasUnwatchedStories: false, hideProfileName: false)
        }
    }
}
