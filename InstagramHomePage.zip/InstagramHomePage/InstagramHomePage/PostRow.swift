//
//  PostRow.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import SwiftUI

struct PostRow: View {
    
    @State var post: PostListRepresentation
    var feedback: (() -> Void)
    
    let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.locale = Locale(identifier: "ru_RU")
        return formatter
    }()
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(uiImage: post.profileImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 35, height: 35)
                    .clipShape(Circle())
                Text(post.profileName)
                    .font(.system(size: 12))
                Spacer()
                Button {
                    feedback()
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 13))
                        .foregroundColor(.black)
                }
            }
            .frame(height: 50)
            .padding(.horizontal)
            
            Image(uiImage: post.image)
                .resizable()
                .scaledToFill()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2)
                .clipped()
                .background(Color.blue)
            
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 12) {
                    Button(action: likePressed) {
                        if post.isLiked {
                            Image(systemName: "heart.fill")
                                .foregroundColor(.red)
                        } else {
                            Image(systemName: "heart")
                        }
                    }
                    
                    Image(systemName: "bubble.right")
                    Image(systemName: "paperplane")
                    
                    Spacer()
                    
                    Button(action: savePressed) {
                        if post.isSaved {
                            Image(systemName: "bookmark.fill")
                                .foregroundColor(.black)
                        } else {
                            Image(systemName: "bookmark")
                        }
                    }
                }
                .foregroundColor(.black)
                .font(.system(size: 24))
                
                Text("Нравится \(post.likesCount) \(getUsersString(for: post.likesCount))")
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                
                if post.description.isEmpty == false {
                    Text(post.description)
                        .font(.system(size: 15))
                }
                
                Text(formatter.string(from: post.date))
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            .animation(nil)
            .padding()
            
        }
    }
    
    func getUsersString(for likesCount: Int) -> String {
        switch likesCount {
        case 1:
            return "пользователю"
        default:
            return "пользователям"
        }
    }
    
    func likePressed() {
        post.isLiked.toggle()
    }
    func savePressed() {
        post.isSaved.toggle()
    }
}

struct PostRow_Previews: PreviewProvider {
    static var previews: some View {
        
        PostRow(post:
                    .init(profileImage: UIImage(systemName: "person.circle")!, profileName: "m_bashtaev", image: UIImage(), likesCount: 12, date: Calendar.current.dateFrom(year: 2019, month: 3, day: 12), description: "", isLiked: true, isSaved: true), feedback: {}
        )
    }
}
