//
//  InstagramHomePageApp.swift
//  InstagramHomePage
//
//  Created by Магомед on 18.05.2021.
//

import SwiftUI

@main
struct InstagramHomePageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
