//
//  ChatRow.swift
//  InstagramHomePage
//
//  Created by Магомед on 19.05.2021.
//

import SwiftUI

struct ChatRow: View {
    
    let profileImage: UIImage
    let profileName: String
    let hasUnwatchedStories: Bool
    
    var body: some View {
        HStack {
            StoryIcon(profileImage: profileImage, profileName: profileName, storyType: .other, hasUnwatchedStories: hasUnwatchedStories, hideProfileName: true)
            VStack(alignment: .leading) {
                Text(profileName)
                    .font(.system(size: 17))
                Text("В сети \(Int.random(in: 1...23)) ч. назад")
                    .font(.system(size: 15))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button(action: {}) {
                Image(systemName: "camera")
                    .font(.system(size: 24))
                    .foregroundColor(.secondary)
            }
        }
    }
}

struct ChatRow_Previews: PreviewProvider {
    static var previews: some View {
        ChatRow(profileImage: UIImage(named: "spacex-profile-image")!, profileName: "SpaceX", hasUnwatchedStories: false)
    }
}
