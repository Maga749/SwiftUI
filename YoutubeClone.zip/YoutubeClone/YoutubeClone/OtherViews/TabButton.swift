//
//  TabButton.swift
//  YoutubeClone
//
//  Created by Магомед on 19.06.2021.
//

import SwiftUI

struct TabButton: View {
    
    var title: String
    var image: String
    
    @Binding var selected: String
    
    var body: some View {
        Button {
            withAnimation(.spring()) {
                selected = title
            }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 25, height: 25)
                    .foregroundColor(title == selected ? .white : .init(UIColor.lightGray))
                
                if title == selected {
                    Text(title)
                        .font(.system(size: 12))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
            }
            .padding(.vertical, 8)
            .padding(.horizontal)
            .background(selected == title ? Color(UIColor.red) : .clear)
            .clipShape(Capsule())
        }
    }
}

//struct TabButton_Previews: PreviewProvider {
//    static var previews: some View {
//        TabButton()
//    }
//}
