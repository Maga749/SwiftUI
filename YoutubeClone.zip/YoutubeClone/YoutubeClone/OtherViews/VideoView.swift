//
//  VideoView.swift
//  YoutubeClone
//
//  Created by Магомед on 19.06.2021.
//

import SwiftUI

struct VideoView: View {
    
    var video: Video.ListRepresentation
    
    var body: some View {
        VStack {
            Image(video.imageString)
                .resizable()
                .frame(height: 200)
            HStack {
                Text(video.title)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.white)
                
                Spacer()
                
                Button(action: {}) {
                    Image(systemName: "ellipsis")
                        .rotationEffect(Angle(degrees: 90))
                }
                .frame(width: 24, height: 24)
                .foregroundColor(.white)
            }
            .padding(.leading, 8)
            
            HStack {
                Text(video.channelName)
                    .foregroundColor(.white)
                    .padding(.vertical, 4)
                    .padding(.horizontal, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(Color("background"))
                    )
                
                Spacer()
                
                Text(video.viewsCount)
                    .foregroundColor(.white)
                    .padding(.vertical, 4)
                    .padding(.horizontal, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(Color("background"))
                    )
                
                Spacer()
                
                Text(video.date)
                    .foregroundColor(.white)
                    .padding(.vertical, 4)
                    .padding(.horizontal, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(Color("background"))
                    )
            }
            .lineLimit(1)
            .padding(.horizontal, 8)
            .font(.system(size: 12))
        }
        .padding(.bottom, 8)
        .background(Color.white.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct VideoView_Previews: PreviewProvider {
    static var previews: some View {
        VideoView(video: Video.videosSample.first!.convertToListRepresentation())
    }
}
