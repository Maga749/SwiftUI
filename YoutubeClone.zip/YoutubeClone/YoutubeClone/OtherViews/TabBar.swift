//
//  TabBar.swift
//  YoutubeClone
//
//  Created by Магомед on 19.06.2021.
//

import SwiftUI

class KeyboardHandler: ObservableObject {
    
    @Published var keyboardIsShown = false
    
    @objc func keyboardWillAppear() {
        keyboardIsShown = true
    }

    @objc func keyboardWillDisappear() {
        keyboardIsShown = false
    }
    
    init() {
        NotificationCenter.default.addObserver(self, selector: #selector(KeyboardHandler.keyboardWillDisappear), name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(KeyboardHandler.keyboardWillAppear), name: UIResponder.keyboardWillShowNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}

struct TabBar: View {
    
    @StateObject var keyboardHandler = KeyboardHandler()
    @State var current = "Home"
    private var pageNames = ["Home", "Trending", "Subscriptions", "Library"]
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .bottom)) {
            TabView(selection: $current) {
                
                HomeView()
                    .tag("Home")
                
                ForEach(0..<3) { index in
                    ZStack {
                        Color("background")
                            .ignoresSafeArea()
                        Text(pageNames[index + 1])
                            .font(.system(size: 35, weight: .medium, design: .rounded))
                            .foregroundColor(.white)
                    }
                    .tag(pageNames[index + 1])
                }
            }
            
            if keyboardHandler.keyboardIsShown == false {
                HStack(spacing: 0) {
                    TabButton(title: "Home", image: "house", selected: $current)
                    Spacer(minLength: 0)
                    TabButton(title: "Trending", image: "flame", selected: $current)
                    Spacer(minLength: 0)
                    TabButton(title: "Subscriptions", image: "restart", selected: $current)
                    Spacer(minLength: 0)
                    TabButton(title: "Library", image: "folder", selected: $current)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 8)
                .background(Color("tabBarColor"))
                .clipShape(Capsule())
                .padding(.horizontal, 8)
                .padding(.bottom, 8)
            }
        }
    }
}

struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar()
    }
}
