//
//  HomeView.swift
//  YoutubeClone
//
//  Created by Магомед on 19.06.2021.
//

import SwiftUI

struct HomeView: View {
    
    @State var text: String = ""
    @State var isEditingTextField = false
    
    var videos = Video.videosSample.map { $0.convertToListRepresentation() }
    
    var body: some View {
        ZStack {
            Color("background")
                .ignoresSafeArea()
            VStack {
                HStack(spacing: 20) {
                    ZStack(alignment: .leading) {
                        if text.isEmpty {
                            Text("Search now")
                                .foregroundColor(Color(UIColor.lightGray))
                                .padding(.horizontal)
                        }
                        TextField("", text: $text) { changed in
//                            withAnimation(.spring()) {
//                                isEditingTextField = true
//                            }
                        } onCommit: {
                            withAnimation(.spring()) {
                                isEditingTextField = false
                            }
                            text = ""
                        }
                        .onChange(of: text) { text in
                            if text.isEmpty == false {
                                withAnimation(.spring()) {
                                    isEditingTextField = true
                                }
                            }
                        }
                        .padding(.horizontal)
                        .frame(height: 44)
                        .background(Color.white.opacity(0.3))
                        .clipShape(Capsule())
                        .foregroundColor(.white)

                    }
                    if isEditingTextField == false {
                        Button(action: {}) {
                            Image(systemName: "video.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                                .foregroundColor(Color(UIColor.lightGray))
                        }
                        Button(action: {}) {
                            Image(systemName: "person.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                                .foregroundColor(Color(UIColor.lightGray))
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                
                Spacer()
                
                ScrollView(.vertical, showsIndicators: true) {
                    LazyVStack(spacing: 8) {
                        ForEach(videos, id: \.title) { video in
                            VideoView(video: video)
                                .padding(.horizontal, 16)
                        }
                        Color.clear
                            .frame(height: 80)
                    }
                    
                }
                
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
