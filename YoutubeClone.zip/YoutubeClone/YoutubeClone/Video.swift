//
//  Video.swift
//  YoutubeClone
//
//  Created by Магомед on 19.06.2021.
//

import Foundation

struct Video {
    var title: String
    var channelName: String
    var viewsCount: Int
    var date: Date
    var imageString: String
    
    typealias ListRepresentation = (title: String, channelName: String, viewsCount: String, date: String, imageString: String)
    
    static var videosSample: [Video] {
        let video1 = Video(title: "Как НА САМОМ ДЕЛЕ работает нейросеть?",
                           channelName: "Droider.Ru",
                           viewsCount: 232_000,
                           date: Calendar.current.date(from: DateComponents(year: 2020, month: 10, day: 8))!,
                           imageString: "Droider1")
        let video2 = Video(title: "Человек-Паук 3 - разбор заявления Sony. Веном и Крейвен в пролете!",
                           channelName: "Marvel/DC: Geek Movies",
                           viewsCount: 242_361,
                           date: Calendar.current.date(from: DateComponents(year: 2021, month: 6, day: 2))!,
                           imageString: "GeekMovies")
        let video3 = Video(title: "Блокчейн, токены, криптовалюта: ЧТО ЭТО? | РАЗБОР",
                           channelName: "Droider.Ru",
                           viewsCount: 304_934,
                           date: Calendar.current.date(from: DateComponents(year: 2021, month: 5, day: 6))!,
                           imageString: "Droider2")
        let video4 = Video(title: "Swift 5.5: Async Await Operations (Xcode 13, iOS 15, 2021) - iOS for Beginners",
                           channelName: "iOS Academy",
                           viewsCount: 2_578,
                           date: Calendar.current.date(from: DateComponents(year: 2020, month: 6, day: 14))!,
                           imageString: "iOSAcademy")
        let video5 = Video(title: "Дмитрий Губерниев х Настя Ивлеева х Олег Майами х Гарик Харламов х Джиган | ЧТО БЫЛО ДАЛЬШЕ?",
                           channelName: "LABELCOM",
                           viewsCount: 47_609_618,
                           date: Calendar.current.date(from: DateComponents(year: 2020, month: 12, day: 31))!,
                           imageString: "ЧБД")
        
        return [video1, video2, video3, video4, video5]
    }
    
    func convertToListRepresentation() -> ListRepresentation {
        
        let viewsCountString: String
        
        switch viewsCount {
        case 0..<1_000:
            viewsCountString = String(viewsCount) + " views"
        case 0..<1_000_000:
            viewsCountString = String(viewsCount / 1_000) + "K views"
        case 0..<1_000_000_000:
            viewsCountString = String(viewsCount / 1_000_000) + "M views"
        case 0...:
            viewsCountString = String(viewsCount / 1_000_000_000) + "B views"
        default:
            viewsCountString = "Error"
        }
        
        let calendar = Calendar.current

        let date1 = calendar.startOfDay(for: date)
        let date2 = calendar.startOfDay(for: Date())

        let components = calendar.dateComponents([.day], from: date1, to: date2)
        let daysCount = components.day ?? 0
        
        let dateString: String
        
        switch daysCount {
        case 0..<31:
            dateString = String(daysCount) + " days ago"
        case 0..<366:
            dateString = String(daysCount / 30) + " months ago"
        case 0...:
            dateString = String(daysCount / 365) + " years ago"
        default:
            dateString = "Error"
        }
        
        return (title, channelName, viewsCountString, dateString, imageString)
    }
}
