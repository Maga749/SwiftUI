//
//  YoutubeCloneApp.swift
//  YoutubeClone
//
//  Created by Магомед on 18.06.2021.
//

import SwiftUI

@main
struct YoutubeCloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
