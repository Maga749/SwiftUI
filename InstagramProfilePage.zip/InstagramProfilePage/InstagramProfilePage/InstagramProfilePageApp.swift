//
//  InstagramProfilePageApp.swift
//  InstagramProfilePage
//
//  Created by Магомед on 19.05.2021.
//

import SwiftUI

@main
struct InstagramProfilePageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
