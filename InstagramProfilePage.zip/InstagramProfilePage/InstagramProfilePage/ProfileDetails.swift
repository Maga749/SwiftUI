//
//  ProfileDetails.swift
//  InstagramProfilePage
//
//  Created by Магомед on 21.05.2021.
//

import SwiftUI

struct ProfileDetails: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @Binding var user: User
    
    var body: some View {
        NavigationView {
            List {
                HStack {
                    Spacer()
                    VStack {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 100))
                            .foregroundColor(.gray)
                        Button("Изменить фото профиля") {
                            
                        }
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(.blue)
                    }
                    .padding(.vertical, 8)
                    Spacer()
                }
                HStack {
                    Text("Имя")
                        .frame(width: 100, alignment: .leading)
                    TextField("Имя", text: $user.name)
                }
                .font(.system(size: 17))
                HStack {
                    Text("Имя пользователя")
                        .font(.system(size: 15))
                        .frame(width: 100, alignment: .leading)
                    TextField("Имя пользователя", text: $user.profileName)
                }
                .font(.system(size: 17))
                HStack {
                    Text("Сайт")
                        .frame(width: 100, alignment: .leading)
                    TextField("Сайт", text: $user.site)
                }
                .font(.system(size: 17))
                HStack {
                    Text("О себе")
                        .frame(width: 100, alignment: .leading)
                    TextField("О себе", text: $user.description)
                }
                .font(.system(size: 17))
                
                Button("Переключиться на профессиональный аккаунт") {
                    
                }
                .font(.system(size: 17))
                .foregroundColor(.blue)
                
                Button("Настройка личной информации") {
                    
                }
                .font(.system(size: 17))
                .foregroundColor(.blue)
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarTitle("Редактировать профиль")
            .navigationBarItems(leading: leadingNavigationBarItem(), trailing: trailingNavigationBarItem())
        }
        .listStyle(PlainListStyle())
    }
    
    private func leadingNavigationBarItem() -> some View {
        Button("Отмена") {
            presentationMode.wrappedValue.dismiss()
        }
        .foregroundColor(.primary)
        .font(.system(size: 17))
    }
    private func trailingNavigationBarItem() -> some View {
        Button("Готово") {
            presentationMode.wrappedValue.dismiss()
        }
        .foregroundColor(.blue)
        .font(.system(size: 17, weight: .bold))
    }
}

struct ProfileDetails_Previews: PreviewProvider {
    static var previews: some View {
        ProfileDetails(user: .constant(User.arianaGrande()))
    }
}
