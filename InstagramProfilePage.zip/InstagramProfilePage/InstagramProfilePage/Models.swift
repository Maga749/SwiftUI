//
//  Model.swift
//  InstagramProfilePage
//
//  Created by Магомед on 20.05.2021.
//

import Foundation

struct User {
    var name: String
    
    var profileName: String
    let profileImageString: String
    
    let publicationsCount: Int
    let subscribersCount: Int
    let subscriptionsCount: Int
    
    var description: String
    let links: [LinkDetails]
    
    let actionStories: [ActualStory]
    let posts: [Post]
    
    var site: String = ""
}

struct Story {
    let imageString: String
    let date: Date
}

struct ActualStory {
    let title: String
    let imageString: String
    let stories: [Story]
}

struct Post {
    let imageString: String
    let likesCount: Int
    var isLiked: Bool
    var isSaved: Bool
    let date: Date
}

struct LinkDetails {
    let title: String
    let urlString: String
}

extension User {
    static func arianaGrande() -> User {
        return User(name: "Ariana Grande",
                    profileName: "arianagrande",
                    profileImageString: "ariana-profile-image",
                    publicationsCount: 4_789,
                    subscribersCount: 235_000_000,
                    subscriptionsCount: 810,
                    description: "American singer, actress, songwriter, music producer, Grammy Award winner",
                    links: [
                        LinkDetails(title: "Youtube channel",
                                    urlString: "https://www.youtube.com/channel/UC9CoOnJkIBMdeijd9qYoT_g")
                    ],
                    actionStories: [
                        ActualStory(title: "my",
                                    imageString: "ariana-actual-story-1",
                                    stories: []),
                        ActualStory(title: "happiness",
                                    imageString: "ariana-actual-story-2",
                                    stories: []),
                        ActualStory(title: "🤍",
                                    imageString: "ariana-actual-story-3",
                                    stories: [])
                    ],
                    posts: [
                        Post(imageString: "ariana-post1",
                             likesCount: 3_298_193,
                             isLiked: true,
                             isSaved: true,
                             date: Calendar.current.dateFrom(year: 2021, month: 4, day: 14)),
                        Post(imageString: "ariana-post2",
                             likesCount: 4_282_819,
                             isLiked: false,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2021, month: 2, day: 12)),
                        Post(imageString: "ariana-post3",
                             likesCount: 6_839_917,
                             isLiked: true,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2020, month: 12, day: 7)),
                        Post(imageString: "ariana-post4",
                             likesCount: 7_738_941,
                             isLiked: false,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2020, month: 10, day: 13)),
                        Post(imageString: "ariana-post5",
                             likesCount: 5_132_524,
                             isLiked: false,
                             isSaved: true,
                             date: Calendar.current.dateFrom(year: 2020, month: 8, day: 6)),
                        Post(imageString: "ariana-post6",
                             likesCount: 3_837_829,
                             isLiked: true,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2020, month: 5, day: 9)),
                        Post(imageString: "ariana-post7",
                             likesCount: 5_839_534,
                             isLiked: false,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2020, month: 3, day: 10)),
                        Post(imageString: "ariana-post8",
                             likesCount: 6_839_253,
                             isLiked: false,
                             isSaved: true,
                             date: Calendar.current.dateFrom(year: 2020, month: 1, day: 3)),
                        Post(imageString: "ariana-post9",
                             likesCount: 4_837_948,
                             isLiked: true,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2019, month: 11, day: 9)),
                        Post(imageString: "ariana-post10",
                             likesCount: 8_837_736,
                             isLiked: false,
                             isSaved: true,
                             date: Calendar.current.dateFrom(year: 2019, month: 9, day: 6)),
                        Post(imageString: "ariana-post11",
                             likesCount: 7_829_153,
                             isLiked: false,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2019, month: 8, day: 21)),
                        Post(imageString: "ariana-post12",
                             likesCount: 8_738_103,
                             isLiked: true,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2019, month: 6, day: 24)),
                        Post(imageString: "ariana-post13",
                             likesCount: 9_382_819,
                             isLiked: false,
                             isSaved: false,
                             date: Calendar.current.dateFrom(year: 2019, month: 4, day: 12)),
                        Post(imageString: "ariana-post14",
                             likesCount: 10_849_917,
                             isLiked: true,
                             isSaved: true,
                             date: Calendar.current.dateFrom(year: 2019, month: 3, day: 28)),
                    ])
    }

}

