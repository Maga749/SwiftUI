//
//  PostView.swift
//  InstagramProfilePage
//
//  Created by Магомед on 20.05.2021.
//

import SwiftUI

struct PostView: View {
    
    @State var post: Post
    let profileName: String
    let profileImageString: String
    let ellipsisButtonHandler: (() -> Void)
    
    @State var showLike = false
    
    private let dateFormatter: DateFormatter = {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.locale = Locale(identifier: "ru_RU")
        return dateFormatter
    }()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(profileImageString)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .clipShape(Circle())
                
                Text(profileName)
                    .font(.system(size: 14, weight: .bold))
                
                Spacer()
                
                Button(action: ellipsisButtonHandler) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 14))
                        .foregroundColor(.primary)
                }
            }
            .padding(.horizontal)
            .frame(height: 50)
            
            ZStack {
                Image(post.imageString)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.6)
                    .clipped()
                    .onTapGesture(count: 2) {
                        
                        withAnimation {
                            post.isLiked.toggle()
                            showLike.toggle()
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            showLike.toggle()
                        }
                    }
                
                Image(systemName: "heart.fill")
                    .font(.system(size: 100))
                    .foregroundColor(.white)
                    .scaleEffect(showLike ? 1 : 0)
                    .opacity(showLike ? 1 : 0)
                    .animation(.default)
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.6)
            
            HStack {
                Button(action: { post.isLiked.toggle() }) {
                    Image(systemName: post.isLiked ? "heart.fill" : "heart")
                        .font(.system(size: 24))
                        .foregroundColor(post.isLiked ? Color.red : .primary)
                }
                Button(action: {}) {
                    Image(systemName: "message")
                        .font(.system(size: 24))
                        .foregroundColor(.primary)
                }
                Button(action: {}) {
                    Image(systemName: "paperplane")
                        .font(.system(size: 24))
                        .foregroundColor(.primary)
                }
                
                Spacer()
                
                Button(action: { post.isSaved.toggle() }) {
                    Image(systemName: post.isSaved ? "bookmark.fill" : "bookmark")
                        .font(.system(size: 24))
                        .foregroundColor(.primary)
                }
            }
            .padding(.horizontal)
            .frame(height: 50)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Нравится \(post.likesCount.toString3SpaceFormat()) пользователям")
                    .font(.system(size: 13, weight: .bold))
                    .padding(.horizontal)
                
                Text(dateFormatter.string(from: post.date))
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
            }
        }
        .padding(.bottom)
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(post: Post(imageString: "ariana-post4", likesCount: 1_292_838, isLiked: true, isSaved: true, date: Date()), profileName: "arianagrande", profileImageString: "ariana-profile-image", ellipsisButtonHandler: {})
    }
}
