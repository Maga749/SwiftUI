//
//  ContentView.swift
//  InstagramProfilePage
//
//  Created by Магомед on 19.05.2021.
//

import SwiftUI

struct ContentView: View {
    
    private let user = User.arianaGrande()
    
    @Environment(\.colorScheme) var colorScheme
    @State private var showProfileDetails = false
    
    private let gradientColors: [Color] = [
        .init(hex: "F58529".lowercased()),
        .init(hex: "FEDA77".lowercased()),
        .init(hex: "DD2A7B".lowercased()),
        .init(hex: "8134AF".lowercased()),
        .init(hex: "515BD4".lowercased()),
    ]
    
    // Modify this property in code to see result in profile icon
    private var hasStories = false
    private var storiesAreUnwatched = false
    
    @State private var selectedTab = 0
        
    @State private var topHeaderOffset: CGFloat = 0
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                HStack {
                    Text(user.profileName)
                        .font(.system(size: 22, weight: .bold))
                    
                    Spacer()
                    
                    HStack(spacing: 20) {
                        Button(action: {}) {
                            Image(systemName: "plus.app")
                                .resizable()
                                .frame(width: 20, height: 20)
                        }
                        Button(action: {}) {
                            Image(systemName: "line.horizontal.3")
                                .resizable()
                                .frame(width: 18, height: 18)
                        }
                        .foregroundColor(.primary)
                    }
                    .foregroundColor(.primary)
                }
                .padding(.horizontal)
                .frame(height: 50)
                
                ScrollView(.vertical, showsIndicators: false) {
                    ScrollViewReader { proxy in
                        VStack(alignment: .leading, spacing: 0) {
                            HStack(spacing: 10) {
                                ZStack {
                                    if hasStories {
                                        if storiesAreUnwatched {
                                            Circle()
                                                .strokeBorder(
                                                    LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .top, endPoint: .bottom), lineWidth: 2
                                                )
                                                .frame(width: 98, height: 98)
                                        } else {
                                            Circle()
                                                .strokeBorder(Color.gray, lineWidth: 1)
                                                .frame(width: 98, height: 98)
                                        }
                                    }
                                    
                                    ZStack(alignment: .bottomTrailing) {
                                        Image(user.profileImageString)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 87, height: 87)
                                            .clipShape(Circle())
                                        
                                        if hasStories == false {
                                            Image(systemName: "plus")
                                                .foregroundColor(.white)
                                                .font(.system(size: 12, weight: .bold))
                                                .padding(4)
                                                .background(
                                                    Circle()
                                                        .foregroundColor(.blue)
                                                )
                                                .padding(2)
                                                .background(
                                                    Circle()
                                                        .foregroundColor(colorScheme == .light ? .white : .black)
                                                )
                                                .offset(x: 2, y: 2)
                                        }
                                    }
                                }
                                
                                HStack {
                                    Button {
                                        withAnimation {
                                            proxy.scrollTo("TabView", anchor: .top)
                                        }
                                    } label: {
                                        VStack {
                                            Text(user.publicationsCount.toString3SpaceFormat())
                                                .font(.system(size: 16, weight: .bold))
                                            Text("публикаций")
                                                .font(.system(size: 13, weight: .regular))
                                                .lineLimit(1)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    Button(action: {}) {
                                        VStack {
                                            Text(user.subscribersCount.toStringPeopleCountFormat())
                                                .font(.system(size: 16, weight: .bold))
                                            Text("подписчиков")
                                                .font(.system(size: 13, weight: .regular))
                                                .lineLimit(1)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                    Button(action: {}) {
                                        VStack {
                                            Text(user.subscriptionsCount.toString3SpaceFormat())
                                                .font(.system(size: 16, weight: .bold))
                                            Text("подписки")
                                                .font(.system(size: 13, weight: .regular))
                                                .lineLimit(1)
                                        }
                                    }
                                    .frame(maxWidth: .infinity)
                                }
                                .foregroundColor(.primary)
                            }
                            .padding(.horizontal)
                            .frame(height: 90)
                            .padding(.bottom)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(user.name)
                                    .font(.system(size: 13, weight: .bold))
                                Text(user.description)
                                    .font(.system(size: 13, weight: .regular))
                                ForEach(user.links, id: \.urlString) { link in
                                    Link(link.title, destination: URL(string: link.urlString)!)
                                        .font(.system(size: 13, weight: .regular))
                                }
                            }
                            .padding(.horizontal)
                            .padding(.bottom)
                            
                            Button(action: { showProfileDetails = true }) {
                                Text("Редактировать профиль")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(.primary)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 30)
                                    .background(
                                        RoundedRectangle(cornerRadius: 4)
                                            .strokeBorder(lineWidth: 1)
                                            .foregroundColor(.gray)
                                    )
                            }
                            .padding(.horizontal)
                            .padding(.bottom)
                            .fullScreenCover(isPresented: $showProfileDetails) {
                                ProfileDetails(user: .constant(user))
                            }
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(user.actionStories, id: \.title) { story in
                                        ActualStoryView(type: .normal, title: story.title, imageString: story.imageString)
                                    }
                                    ActualStoryView(type: .add, title: "", imageString: "")
                                }
                            }
                            .padding(.horizontal)
                            .padding(.bottom)
                            
                            Divider()
                            
                            GeometryReader { proxy -> AnyView in
                                let minY = proxy.frame(in: .global).minY
                                let safeAreaTopInset = UIApplication.shared.keyWindow?.safeAreaInsets.top ?? UIApplication.shared.statusBarFrame.size.height
                                let offset = safeAreaTopInset + 50 - minY
                                
                                return AnyView(
                                    tabView()
                                        .offset(y: offset < 0 ? 0 : offset)
                                )
                            }
                            .frame(height: 46)
                            .zIndex(10)
                            .id("TabView")
                            
                            LazyVGrid(columns: [GridItem(), GridItem(), GridItem()],
                                      alignment: .center,
                                      spacing: 2) {
                                
                                ForEach(0..<user.posts.count, id: \.self) { postIndex in
                                    NavigationLink(destination: PhotoTape(user: user, scrollToItemIndex: postIndex)) {
                                        Image(user.posts[postIndex].imageString)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: (UIScreen.main.bounds.width) / 3, height: (UIScreen.main.bounds.width) / 3)
                                            .clipped()
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
    
    private func tabView() -> some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Button {
                    withAnimation {
                        selectedTab = 0
                    }
                } label: {
                    Color.clear
                        .overlay(
                            Image(systemName: "squareshape.split.3x3")
                                .resizable()
                                .frame(width: 20, height: 20)
                                .foregroundColor(.primary)
                        )
                }
                Button {
                    withAnimation {
                        selectedTab = 1
                    }
                } label: {
                    Color.clear
                        .overlay(
                            Image(systemName: "film")
                                .resizable()
                                .frame(width: 20, height: 20)
                                .foregroundColor(.primary)
                        )
                }
                Button {
                    withAnimation {
                        selectedTab = 2
                    }
                } label: {
                    Color.clear
                        .overlay(
                            Image(systemName: "person.crop.square")
                                .resizable()
                                .frame(width: 20, height: 20)
                                .foregroundColor(.primary)
                        )
                }
            }
            
            let width = UIScreen.main.bounds.width
            
            Color.primary
                .frame(width: UIScreen.main.bounds.width / 3, height: 1)
                .offset(x: (width / 3) * CGFloat(selectedTab - 1))
        }
        .frame(height: 45)
        .padding(.bottom, 1)
        .background(colorScheme == .light ? Color.white : .black)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
