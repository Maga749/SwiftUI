//
//  PhotoTape.swift
//  InstagramProfilePage
//
//  Created by Магомед on 20.05.2021.
//

import SwiftUI

struct PhotoTape: View {
    
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
     
    @State var user: User
    var scrollToItemIndex: Int
    
    @State var showActionSheet = false
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                ZStack {
                    HStack {
                        Button(action: { presentationMode.wrappedValue.dismiss() }) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 24))
                                .foregroundColor(.primary)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    VStack {
                        Text(user.profileName.uppercased())
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.secondary)
                        Text("Публикации")
                            .font(.system(size: 15, weight: .bold))
                    }
                }
                .frame(height: 50)
                
                Divider()
                
                ScrollView {
                    ScrollViewReader { reader in
                                        
                        ForEach(0..<user.posts.count, id: \.self) { postIndex in
                            
                            PostView(post: user.posts[postIndex],
                                     profileName: user.profileName,
                                     profileImageString: user.profileImageString,
                                     ellipsisButtonHandler: {
                                        self.showActionSheet = true
                                     })
                                .id(postIndex)
                        }
                        .onAppear {
                            reader.scrollTo(scrollToItemIndex, anchor: .top)
                        }
                    }
                }
                .navigationBarHidden(true)
                .navigationBarBackButtonHidden(true)
            }
            
            if showActionSheet {
                Color.black
                    .opacity(0.3)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        showActionSheet = false
                    }
            }
            
            actionSheet()
        }
        .animation(.default)
    }
    
    func actionSheet() -> some View {
        VStack {
            Spacer()
            
            VStack(spacing: 8) {
                VStack(spacing: 0) {
                    ForEach(0..<7) { index in
                        actionSheetButton(title: actionSheetButtonTitles[index], titleColor: index == 0 ? Color.red : .primary)
                        if index != 6 {
                            Divider()
                        }
                    }
                }
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .frame(maxWidth: UIScreen.main.bounds.width - 32)
                        .foregroundColor(colorScheme == .light ? .white : .customGray)
                )
                
                actionSheetButton(title: actionSheetButtonTitles.last!, titleColor: .primary)
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .frame(maxWidth: UIScreen.main.bounds.width - 32)
                        .foregroundColor(colorScheme == .light ? .white : .customGray)
                )
            }
        }
        .offset(y: showActionSheet ? -16 : UIScreen.main.bounds.height)
    }
    
    func actionSheetButton(title: String, titleColor: Color) -> some View {
        Button(action: { showActionSheet = false }) {
            Text(title)
                .frame(height: 55)
                .frame(maxWidth: UIScreen.main.bounds.width - 32)
                .foregroundColor(titleColor)
        }
    }
    let actionSheetButtonTitles = [
        "Удалить",
        "Архивировать",
        "Скрыть число отметок \"Нравится\"",
        "Выключить комментарии",
        "Изменить",
        "Копировать ссылку",
        "Поделиться...",
        "Отмена",
    ]
}

struct PhotoTape_Previews: PreviewProvider {
    static var previews: some View {
        PhotoTape(user: User.arianaGrande(), scrollToItemIndex: 5)
    }
}
