//
//  ActualStoryView.swift
//  InstagramProfilePage
//
//  Created by Магомед on 19.05.2021.
//

import SwiftUI

struct ActualStoryView: View {
    
    enum ViewType {
        case normal
        case add
    }
    
    let type: ViewType
    let title: String
    let imageString: String
    
    var body: some View {
        Button(action: {}) {
            VStack {
                if type == .add {
                    ZStack {
                        Circle()
                            .strokeBorder(Color.gray, lineWidth: 0.5)
                            .frame(width: 63, height: 63)
                        
                        Image(systemName: "plus")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(.primary)
                    }
                } else {
                    ZStack {
                        Circle()
                            .strokeBorder(Color.gray, lineWidth: 1)
                            .frame(width: 63, height: 63)
                        
                            Image(imageString)
                                .resizable()
                                .scaledToFill()
                                .clipShape(Circle())
                                .frame(width: 55, height: 55)
                    }
                }
                Text(type == .add ? "Добавить" : title)
                    .font(.system(size: 10, weight: .regular))
                    .lineLimit(1)
                    .foregroundColor(.primary)
            }
        }
    }
}

struct ActualStoryView_Previews: PreviewProvider {
    static var previews: some View {
        HStack {
            ActualStoryView(type: .normal, title: "happiness", imageString: "actual-story-1")
            ActualStoryView(type: .add, title: "", imageString: "")
        }
    }
}
