//
//  Extensions.swift
//  InstagramProfilePage
//
//  Created by Магомед on 20.05.2021.
//

import Foundation
import SwiftUI

extension Color {
    init(hex: String) {
        
        if
            let red   = Int(hex[hex.startIndex...hex.index(hex.startIndex, offsetBy: 1)], radix: 16),
            let green = Int(hex[hex.index(hex.startIndex, offsetBy: 2)...hex.index(hex.startIndex, offsetBy: 3)], radix: 16),
            let blue  = Int(hex[hex.index(hex.startIndex, offsetBy: 4)...hex.index(hex.startIndex, offsetBy: 5)], radix: 16) {
            
            self.init(red: Double(red) / 255, green: Double(green) / 255, blue: Double(blue) / 255)
            
        } else {
            self.init(red: 0, green: 0, blue: 0)
        }
    }
    
    static let customGray = Color(hex: "262626")
}

extension Calendar {
    func dateFrom(year: Int, month: Int, day: Int) -> Date {
        let dateComponents = DateComponents(year: year, month: month, day: day)
        return Calendar.current.date(from: dateComponents) ?? Date()
    }
}

extension Int {
    func toString3SpaceFormat() -> String {
        var string = ""
        var number = self
        
        while number > 0 {
            let last3Nums = number % 1000
            string.insert(contentsOf: " \(last3Nums)", at: string.startIndex)
            number /= 1000
        }
        string.removeFirst()
        
        return string
    }
    func toStringPeopleCountFormat() -> String {
        
        switch self {
        case ..<1_000:
            return String(self)
        case ..<1_000_000:
            let thousands = Float(self) / 1_000
            return String(format: "%.1f", thousands) + " тыс"
        default:
            return String(self / 1_000_000) + " млн"
        }
    }
}
