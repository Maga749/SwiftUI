//
//  SpotifyUIApp.swift
//  SpotifyUI
//
//  Created by Магомед on 25.05.2021.
//

import SwiftUI

@main
struct SpotifyUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
