//
//  Home.swift
//  SpotifyUI
//
//  Created by Магомед on 25.05.2021.
//

import SwiftUI

struct Home: View {
    
   @State var searchText = ""
    
    var body: some View {
        HStack(spacing: 0) {
                        
            SideTabView()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 15) {
                    HStack(spacing: 15) {
                        HStack(spacing: 15) {
                            Circle()
                                .stroke(Color.white, lineWidth: 4)
                                .frame(width: 25, height: 25)
                            TextField("Search...", text: $searchText)
                        }
                        .padding(.vertical, 10)
                        .padding(.horizontal)
                        .background(Color.white.opacity(0.08))
                        .cornerRadius(8)
                        
                        Button(action: {}) {
                            Image("profile")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 45, height: 45)
                                .cornerRadius(10)
                        }
                    }
                    
                    Text("Recently Played")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 30)
                        
                    TabView {
                        ForEach(recentlyPlayed) { item in
                            Image(item.album_cover)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .cornerRadius(20)
                                .padding(.horizontal)
                        }
                    }
                    .frame(height: 350)
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .padding(.top, 20)
                }
                .padding()
                .frame(maxWidth: .infinity)
            }
        }
        .background(Color("bg").ignoresSafeArea())
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}


