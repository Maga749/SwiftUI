//
//  ContentView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 26.06.2021.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        ZStack {
            Color("background")
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack {
                    Button(action: {}) {
                        Color.white
                            .frame(width: 40, height: 40)
                            .cornerRadius(10)
                            .overlay(
                                Image(systemName: "circle.grid.2x2.fill")
                                    .font(.system(size: 24))
                                    .foregroundColor(.gray)
                            )
                            .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                    }
                    
                    Spacer()
                    
                    Button(action: {}) {
                        Color.white
                            .frame(width: 40, height: 40)
                            .cornerRadius(10)
                            .overlay(
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 24))
                                    .foregroundColor(.gray)
                            )
                            .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                
                ZStack {
                    MainCardView(isEmpty: true)
                        .offset(y: 30)
                        .opacity(0.4)
                        .padding(.horizontal, 30)
                    MainCardView(isEmpty: true)
                        .offset(y: 15)
                        .opacity(0.7)
                        .padding(.horizontal, 15)
                    MainCardView(isEmpty: false)
                }
                .padding(.horizontal)
                
                Spacer(minLength: 50)
                
                GeometryReader { proxy in
                    HStack(spacing: 20) {
                        VStack(spacing: 20) {
                            VStack(alignment: .leading) {
                                HStack {
                                    Text("Gym")
                                        .fontWeight(.semibold)
                                        .foregroundColor(.gray)
                                    Spacer()
                                    Image(systemName: "case.fill")
                                        .foregroundColor(Color("orange"))
                                }
                                Spacer()
                                VStack(alignment: .leading) {
                                    Text("1.30")
                                        .font(.system(size: 20, weight: .bold))
                                    Text("Hours")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.gray)
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity, maxHeight: proxy.size.height * 0.4)
                            .background(
                                Color.white
                                    .cornerRadius(20)
                                    .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                            )
                            
                            VStack(alignment: .leading) {
                                HStack {
                                    Text("Heart")
                                        .fontWeight(.semibold)
                                        .foregroundColor(.white)
                                    Spacer()
                                    Image(systemName: "suit.heart.fill")
                                        .foregroundColor(.white)
                                }
                                Spacer()
                                CardiogramView()
                                    .frame(maxHeight: 50)
                                Spacer()
                                VStack(alignment: .leading) {
                                    Text("72")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                    Text("bpm")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity, maxHeight: proxy.size.height * 0.6)
                            .background(
                                Color("orange")
                                    .cornerRadius(20)
                                    .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                            )
                        }
                        VStack(spacing: 20) {
                            VStack {
                                HStack {
                                    Text("Walk")
                                        .fontWeight(.semibold)
                                        .foregroundColor(.gray)
                                    Spacer()
                                    Image(systemName: "figure.walk")
                                        .foregroundColor(Color("orange"))
                                }
                                Spacer()
                                ZStack {
                                    Circle()
                                        .stroke(lineWidth: 10)
                                        .foregroundColor(Color(UIColor.systemGray5))
                                    Circle()
                                        .trim(from: 0, to: 0.75)
                                        .stroke(style: StrokeStyle(lineWidth: 10))
                                        .foregroundColor(Color("orange"))
                                    VStack {
                                        Text("4367")
                                            .font(.system(size: 17, weight: .bold))
                                        Text("Steps")
                                            .font(.system(size: 15, weight: .semibold))
                                            .foregroundColor(.gray)
                                    }
                                }
                                .padding(8)
                            }
                            .padding()
                            .frame(maxWidth: .infinity, maxHeight: proxy.size.height * 0.6)
                            .background(
                                Color.white
                                    .cornerRadius(20)
                                    .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                            )
                            VStack(alignment: .leading) {
                                HStack {
                                    Text("Sleep")
                                        .fontWeight(.semibold)
                                        .foregroundColor(.gray)
                                    Spacer()
                                    Image(systemName: "moon.fill")
                                        .foregroundColor(Color("orange"))
                                }
                                Spacer()
                                VStack(alignment: .leading) {
                                    Text("6.30")
                                        .font(.system(size: 20, weight: .bold))
                                    Text("Hours")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.gray)
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity, maxHeight: proxy.size.height * 0.4)
                            .background(
                                Color.white
                                    .cornerRadius(20)
                                    .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
                            )
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .padding(.top)
            .padding(.bottom, 70)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
