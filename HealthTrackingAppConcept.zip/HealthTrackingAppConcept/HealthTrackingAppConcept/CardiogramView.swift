//
//  CardiogramView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 27.06.2021.
//

import SwiftUI

struct CardiogramView: View {
    var body: some View {
        GeometryReader { proxy in
            let localHeight = proxy.frame(in: .local).height
            let localWidth  = proxy.frame(in: .local).width
            
            Path { path in
                path.move(to: CGPoint(x: 0, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.14, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.17, y: localHeight * 3/4 - localHeight * 0.1))
                path.addLine(to: CGPoint(x: localWidth * 0.2, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.25, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.35, y: 0))
                path.addLine(to: CGPoint(x: localWidth * (0.25 + 0.2 + 0.2 / 3 / 2), y: localHeight))
                path.addLine(to: CGPoint(x: localWidth * (0.45 + (0.2) * 2/3), y: localHeight * 0.25))
                path.addLine(to: CGPoint(x: localWidth * 0.65, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.80, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth * 0.83, y: localHeight * 3/4 - localHeight * 0.1))
                path.addLine(to: CGPoint(x: localWidth * 0.86, y: localHeight * 3/4))
                path.addLine(to: CGPoint(x: localWidth, y: localHeight * 3/4))
            }
            .stroke(Color.white, lineWidth: 2)
        }
    }
}

struct CardiogramView_Previews: PreviewProvider {
    static var previews: some View {
        CardiogramView()
    }
}
