//
//  CardView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 26.06.2021.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView()
    }
}
