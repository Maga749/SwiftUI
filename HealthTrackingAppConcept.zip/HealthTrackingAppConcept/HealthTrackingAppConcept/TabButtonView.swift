//
//  TabButtonView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 27.06.2021.
//

import SwiftUI

struct TabButtonView: View {
    
    @Binding var selection: String
    var title: String
    var image: String
    
    var body: some View {
        Button{
            selection = title
        } label: {
            VStack {
                Image(systemName: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 25, height: 25)
                    .foregroundColor(selection == title ? Color("orange") : .gray)
                
                if selection == title {
                    Circle()
                        .frame(width: 5, height: 5)
                        .foregroundColor(Color("orange"))
                }
            }
        }
    }
}

struct TabButtonView_Previews: PreviewProvider {
    static var previews: some View {
        TabButtonView(selection: .constant("Home"), title: "Home", image: "house")
    }
}
