//
//  CardView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 26.06.2021.
//

import SwiftUI

struct MainCardView: View {
    
    var isEmpty: Bool
    
    var body: some View {
        Color("orange")
            .overlay(
                VStack {
                    if isEmpty == false {
                        HStack(spacing: 0) {
                        VStack(alignment: .leading, spacing: 0) {
                            Text("My Target")
                                .font(.system(size: 20, weight: .bold))
                                .padding(.bottom, 15)
                            Text("For Today")
                                .font(.system(size: 17))
                                .padding(.bottom, 20)
                            Text("2 of 5 completed")
                                .font(.system(size: 15))
                        }
                        .foregroundColor(.white)
                        .padding(.leading, 20)
                            
                        Spacer()
                        
                        Circle()
                            .foregroundColor(Color.white.opacity(0.3))
                            .frame(width: 100, height: 100)
                            .overlay(
                                Circle()
                                    .foregroundColor(.white)
                                    .frame(width: 75, height: 75)
                                    .overlay(
                                        HStack(alignment: .bottom, spacing: 4) {
                                            Text("40")
                                                .font(.system(size: 22, weight: .bold))
                                            Text("%")
                                                .font(.system(size: 13))
                                        }
                                    )
                            )
                            .padding(.trailing, 20)
                    }
                        .background(Color("orange"))
                    }
                }
            )
            .frame(maxWidth: .infinity, maxHeight: 150)
            .cornerRadius(20)
    }
}

struct MainCardView_Previews: PreviewProvider {
    static var previews: some View {
        MainCardView(isEmpty: true)
    }
}
