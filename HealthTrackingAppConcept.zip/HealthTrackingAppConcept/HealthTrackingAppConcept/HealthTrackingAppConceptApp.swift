//
//  HealthTrackingAppConceptApp.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 26.06.2021.
//

import SwiftUI

@main
struct HealthTrackingAppConceptApp: App {
    var body: some Scene {
        WindowGroup {
            TabBarView()
        }
    }
}
