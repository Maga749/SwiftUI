//
//  TabBarView.swift
//  HealthTrackingAppConcept
//
//  Created by Магомед on 27.06.2021.
//

import SwiftUI

struct TabBarView: View {
    
    @State private var selection: String = "Home"
    private var pageNames = ["Home", "Calendar", "Notifications", "Profile"]
    
    init() {
        UITabBar.appearance().isHidden = true
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selection) {
                HomeView()
                    .tag(pageNames[0])
                
                ForEach(1 ..< 4) { pageNumber in
                    Text(pageNames[pageNumber])
                        .tag(pageNames[pageNumber])
                }
            }
            
            HStack {
                TabButtonView(selection: $selection, title: "Home", image: "house.fill")
                Spacer()
                TabButtonView(selection: $selection, title: "Calendar", image: "calendar")
                Spacer()
                TabButtonView(selection: $selection, title: "Notifications", image: "bell.fill")
                Spacer()
                TabButtonView(selection: $selection, title: "Profile", image: "person.fill")
            }
            .padding(.horizontal)
            .padding(8)
            .background(Color.white)
            .cornerRadius(10)
            .padding(16)
            .shadow(color: Color(UIColor.systemGray3), radius: 10, x: 0, y: 0)
        }
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView()
    }
}
